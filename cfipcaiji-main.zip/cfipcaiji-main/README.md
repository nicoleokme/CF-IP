每3小时自动抓取
https://monitor.gacjie.cn/page/cloudflare/ipv4.html和
 https://ip.164746.xyz
的优选ip，形成ip.txt 
还有js自动生成的https://cf.090227.xyz 和
https://stock.hostmonit.com/CloudFlareYes
